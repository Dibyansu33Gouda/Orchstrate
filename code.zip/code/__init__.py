"""
Package marker for code directory.
"""
